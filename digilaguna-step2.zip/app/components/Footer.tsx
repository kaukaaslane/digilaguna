"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

const navLinkClass = "link-nav";

export default function Footer() {
  const pathname = usePathname();

  return (
    <footer className="border-t border-line bg-bg text-text">
      <div className="site-container py-12">
        <div className="flex flex-col items-start justify-between gap-6 md:flex-row md:items-center">
          <div>
            <div className="text-lg font-semibold text-text">
              DIGILAGUNA
            </div>

            <div className="text-sm text-text-secondary">
              Ideas into digital.
            </div>
          </div>

          <nav className="flex flex-wrap gap-x-4 gap-y-2 text-sm text-text">
            <Link href="/services" className={navLinkClass}>
              Services
            </Link>

            <Link href="/work" className={navLinkClass}>
              Work
            </Link>

            <Link href="/digital-visuals" className={navLinkClass}>
              Digital Visuals
            </Link>

            <Link href="/about" className={navLinkClass}>
              About
            </Link>

            <Link href="/contact" className={navLinkClass}>
              Contact
            </Link>
          </nav>
        </div>

        <div className="mt-6 border-t border-line pt-5">
          <nav
            aria-label="Legal"
            className="flex flex-wrap gap-x-5 gap-y-2 text-xs text-text-secondary"
          >
            <Link
              href="/privacy"
              className="link-nav"
            >
              Privacy Policy
            </Link>

            <Link
              href="/terms"
              className="link-nav"
            >
              Terms of Service
            </Link>

            <Link
              href="/cookies"
              className="link-nav"
            >
              Cookie Policy
            </Link>

            <Link
              href="/legal-notice"
              className="link-nav"
            >
              Legal Notice
            </Link>
          </nav>
        </div>

        <div className="mt-8 flex items-center justify-between gap-6">
          <div className="text-xs text-text-faint">
            © {new Date().getFullYear()} Digilaguna OÜ
          </div>

          {pathname !== "/contact" && (
            <div>
              <Link
                href="/contact"
                className="btn btn-secondary"
              >
                <span>Start a project</span>

                <span
                  aria-hidden
                  className="btn-arrow"
                >
                  →
                </span>
              </Link>
            </div>
          )}
        </div>
      </div>
    </footer>
  );
}