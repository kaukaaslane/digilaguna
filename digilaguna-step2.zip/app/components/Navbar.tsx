﻿"use client";

import React, { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";

export default function Navbar() {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);
  const closeBtnRef = useRef<HTMLButtonElement | null>(null);

  const closeMenu = () => setOpen(false);

  useEffect(() => {
    // Lock background scroll when menu is open
    if (open) {
      document.body.style.overflow = "hidden";

      // Focus the close button inside the overlay
      setTimeout(() => closeBtnRef.current?.focus(), 0);
    } else {
      document.body.style.overflow = "";
    }

    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") closeMenu();
    };

    document.addEventListener("keydown", onKey);

    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [open]);

  return (
    <header className="sticky top-0 z-40 rule bg-bg">
      <div className="site-container flex items-center justify-between py-5">
        <div>
          <Link
            href="/"
            className="cursor-pointer text-lg font-semibold tracking-tight text-text"
          >
            DIGILAGUNA
          </Link>

          <div className="text-xs text-text-secondary">
            Ideas into digital.
          </div>
        </div>

        {/* Desktop navigation */}
        <nav className="hidden items-center gap-6 text-sm text-text md:flex">
          <Link
            href="/services"
            data-active={pathname === "/services"}
            className="link-nav"
          >
            Services
          </Link>

          <Link
            href="/work"
            data-active={pathname === "/work"}
            className="link-nav"
          >
            Work
          </Link>

          <Link
            href="/digital-visuals"
            data-active={pathname === "/digital-visuals"}
            className="link-nav"
          >
            Digital Visuals
          </Link>

          <Link
            href="/about"
            data-active={pathname === "/about"}
            className="link-nav"
          >
            About
          </Link>

          <Link
            href="/contact"
            data-active={pathname === "/contact"}
            className="link-nav"
          >
            Contact
          </Link>

          {pathname !== "/contact" && (
            <Link
              href="/contact"
            data-active={pathname === "/contact"}
              className="btn btn-secondary"
            >
              <span>Start a project</span>

              <span
                aria-hidden
                className="btn-arrow"
              >
                →
              </span>
            </Link>
          )}
        </nav>

        {/* Mobile hamburger */}
        <div className="md:hidden">
          <button
            type="button"
            aria-controls="mobile-menu"
            aria-expanded={open}
            aria-label={open ? "Close menu" : "Open menu"}
            onClick={() => setOpen((v) => !v)}
            className="btn-icon"
          >
            {open ? (
              <svg
                width="20"
                height="20"
                viewBox="0 0 24 24"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
                aria-hidden
              >
                <path
                  d="M18 6L6 18"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
                <path
                  d="M6 6L18 18"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            ) : (
              <svg
                width="20"
                height="20"
                viewBox="0 0 24 24"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
                aria-hidden
              >
                <path
                  d="M3 6h18"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
                <path
                  d="M3 12h18"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
                <path
                  d="M3 18h18"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            )}
          </button>
        </div>
      </div>

      {/* Mobile overlay menu */}
      {open && (
        <div
          id="mobile-menu"
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex flex-col bg-bg text-text"
        >
          {/* Header row inside overlay */}
          <div className="flex items-center justify-between rule px-6 py-5">
            <div>
              <Link
                href="/"
                onClick={closeMenu}
                className="cursor-pointer text-lg font-semibold tracking-tight text-text"
              >
                DIGILAGUNA
              </Link>

              <div className="text-xs text-text-secondary">
                Ideas into digital.
              </div>
            </div>

            <div>
              <button
                ref={closeBtnRef}
                type="button"
                aria-label="Close menu"
                onClick={closeMenu}
                className="btn-icon"
              >
                <svg
                  width="20"
                  height="20"
                  viewBox="0 0 24 24"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                  aria-hidden
                >
                  <path
                    d="M18 6L6 18"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                  <path
                    d="M6 6L18 18"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
              </button>
            </div>
          </div>

          <div className="overflow-auto px-6 py-8">
            <nav className="flex min-h-[60vh] flex-col gap-6 text-xl text-text">
              <Link
                href="/services"
            data-active={pathname === "/services"}
                onClick={closeMenu}
                className="link-nav block"
              >
                Services
              </Link>

              <Link
                href="/work"
            data-active={pathname === "/work"}
                onClick={closeMenu}
                className="link-nav block"
              >
                Work
              </Link>

              <Link
                href="/digital-visuals"
            data-active={pathname === "/digital-visuals"}
                onClick={closeMenu}
                className="link-nav block"
              >
                Digital Visuals
              </Link>

              <Link
                href="/about"
            data-active={pathname === "/about"}
                onClick={closeMenu}
                className="link-nav block"
              >
                About
              </Link>

              <Link
                href="/contact"
            data-active={pathname === "/contact"}
                onClick={closeMenu}
                className="link-nav block"
              >
                Contact
              </Link>

              {pathname !== "/contact" && (
                <div className="mt-6">
                  <Link
                    href="/contact"
            data-active={pathname === "/contact"}
                    onClick={closeMenu}
                    className="btn btn-secondary"
                  >
                    <span>Start a project</span>

                    <span
                      aria-hidden
                      className="btn-arrow"
                    >
                      →
                    </span>
                  </Link>
                </div>
              )}
            </nav>
          </div>
        </div>
      )}
    </header>
  );
}