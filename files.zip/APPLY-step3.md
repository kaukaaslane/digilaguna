# Step 3 — multilingual

Contains everything from steps 1 and 2. Apply this one alone.

**This is the riskiest change so far and I could not compile it.** Restructuring
into `app/[locale]/` touches routing, and Next 16.3.1 is past my knowledge
cutoff. Expect to fix something. Run `npm.cmd run build` before anything else.

## Languages

Estonian (default), English, Russian, Finnish. Every locale is prefixed:
`/et`, `/en`, `/ru`, `/fi`. Bare `/` redirects via middleware — browser
`Accept-Language` first, then a `NEXT_LOCALE` cookie once the visitor picks.

## New files

```
i18n/config.ts               locales, BCP-47 tags, localizePath()
i18n/get-dictionary.ts       lazy loader — /et never downloads Russian strings
i18n/dictionaries/en.ts      source of truth; Dictionary type derives from it
i18n/dictionaries/{et,ru,fi}.ts
middleware.ts                locale detection + redirect
app/layout.tsx               pass-through (html/body moved down a level)
app/[locale]/layout.tsx      html/body, fonts, hreflang, per-locale metadata
app/components/LocaleSwitcher.tsx
app/sitemap.ts               44 entries: 11 routes x 4 locales, with alternates
app/robots.ts
```

Every page moved from `app/*` to `app/[locale]/*`. `app/api/` did not move —
API routes should not be locale-scoped.

## Type safety

`en.ts` is declared `as const` and exports `Dictionary = typeof en`. The other
three are typed `const et: Dictionary`. **A missing or misspelled key is a
compile error, not a blank space on the page.** All three currently match en
exactly.

## The Don Draper pass

Applied to English only, then translated from that. Doing it the other way
round would have meant punching up four languages in parallel and hoping they
still matched.

| before | after |
|---|---|
| "We figure out what to build." | "We work out what to build." |
| "Bring us a problem, a rough idea or something you know could work better. We'll help you figure out what comes next." | "A problem. A rough idea. A hunch that something could work better. That is enough to start." |
| "Not every business needs a complicated website." | "Not every business needs a website." |
| "Sometimes the right solution is simpler. Sometimes it isn't. We start by understanding…" | "Sometimes the answer is smaller than you expected. Sometimes it is bigger. Either way, we find out before anyone writes a line of code." |
| "Online stores built around the way you actually sell — not around a template." | "…built around the way you actually sell. Not around a template." |

I deliberately did **not** touch "You bring the idea", "The technology comes
after the idea", or "Have something worth building?" — those were already the
strongest lines on the site and punching them further would have made them
harder to translate for no gain.

Note the restraint on the hero: it stays plain on purpose. Plain English
survives Estonian, Russian and Finnish. Clever English does not.

## Fonts

`subsets` was `["latin"]`, which has no Cyrillic and no `õ`. Now
`["latin", "latin-ext", "cyrillic"]` with `display: "swap"`. This increases
font payload — if it hurts your LCP, split the Cyrillic subset behind the `ru`
locale.

## Translation quality — read this

**Get a native speaker to review the Estonian before you launch it.** Estonian
is your home market. Awkward Estonian on an Estonian studio's site costs you
more than English-only would. I am reasonably confident in the Russian, less
so in the Finnish, and least in the Estonian marketing register — which is
exactly backwards from what you need.

Specific things to check:
- `Ideedest digitaalseks` as the tagline — grammatical, but a native ear
  should confirm it does not read stiff.
- `Sina tuled ideega` uses informal *sina*. Estonian B2B often prefers *teie*.
  That is a brand decision, not a grammar one.
- Finnish `Sinä tuot idean` — same informal/formal question.
- Russian uses formal *вы* throughout. Consistent, and right for B2B.

## Done vs pending

Localized: Navbar, Footer, LocaleSwitcher, homepage, all metadata, sitemap,
robots, 404.

**Not yet localized** — these pages still render English regardless of locale:
`/services`, `/work`, `/work/dropmow`, `/digital-visuals`, `/about`, `/contact`,
and the four legal pages. Dictionary sections for `about` and `contact` are
already written and typed; the pages just need wiring. `/services`, `/work`,
`/work/dropmow` and legal need their content extracted first (~1,400 words).

`app/brief/page.tsx` moved with the rest but is still an untouched orphan.

## Apply

```powershell
git checkout -b i18n
Unblock-File .\digilaguna-step3.zip
Remove-Item -Recurse -Force .\public
Expand-Archive -Path .\digilaguna-step3.zip -DestinationPath . -Force
```

Then delete the stale originals that `Expand-Archive` cannot remove — the old
page files still sit at `app/*` and will collide with `app/[locale]/*`:

```powershell
Remove-Item -Recurse -Force .\app\about, .\app\contact, .\app\cookies,
  .\app\digital-visuals, .\app\legal-notice, .\app\privacy, .\app\services,
  .\app\terms, .\app\work, .\app\brief
Remove-Item -Force .\app\page.tsx
```

**That step is not optional.** Two files resolving to the same route is a build
error at best and a silently wrong page at worst.

```powershell
npm.cmd run build
```

## Expected trouble

1. **`params` is a Promise.** Next 15+ made route params async; I wrote
   `await params` throughout. If 16.3.1 changed this again, that is the first
   thing to fix.
2. **Root layout returning bare `children`.** Next wants `<html>`/`<body>` in
   the root layout. With `[locale]` they have to live one level down. If the
   build complains, the fix is usually moving the font variables up.
3. **`@/` path alias.** Your `tsconfig.json` maps `@/*` to `./*`, so
   `@/i18n/config` resolves to `<root>/i18n/config`. Verify it resolves.
4. **Middleware matcher.** `/((?!api|_next|.*\..*).*)`  should skip API, Next
   internals and static files. If `/sitemap.xml` starts redirecting, that
   regex is why.

Paste me the build output. This one I expect to need a round of fixes.
